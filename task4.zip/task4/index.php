<!DOCTYPE html>
<html lang="en">
<head>
    <title>Web Programming using PHP - Coursework 1 - Task 4</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="stylesheet" type="text/css" href="css/plain.css" />
</head>
<body>
	<header>   
        <h1>Web Programming using PHP - Coursework 1 </h1>
		<h2>Task 4</h2>
		<h3>Module data results for php</h3>
	</header>
	<main>
        <!--Your PHP solution code should go here-->
		<?php
			// Read the data file and convert module marks into an integer array
			function readMarksFromFile($filename) {
				$grades = [];

				// open the file in read mode 
				$file = fopen($filename, "r");

				// check if the file exists
				if ($file) {
					// read each line from the file
					while (($line = fgets($file)) !== false) {

						// split each line into an array of values using ',' delimiter
						$values = explode(",", $line);

						// extract the second value for each line in the file
						$grade = trim($values[1]);

						// add $grade value to the $grades array 
						$grades[] = $grade;
					}
					// close the file
					fclose($file);
				}
				return $grades;
			}

			// Format the data series as [56, 67, ... 15]
			function formatDataSeries($marks) {
				// implode() function concatenate each mark into a string using ',' separator
				return "[" . implode(',', $marks) . "]";
			}
		
			// Calculate the statistical mean mark
			function calculateStatisticalMeanMark($marks) {
				return array_sum($marks) / count($marks);
			}

			// Calculate the statistical range
			function calculateStatisticalRange($marks) {
				return max($marks) - min($marks);
			}
		
			// Determine the grade distribution and count total number of students
			function calculateGradeDistribution($marks) {

				// an array in which each key "A", "B", "C", "D" and "F", initialized with a value of 0.
				$gradeDistribution = [
					'A' => 0,
					'B' => 0,
					'C' => 0,
					'D' => 0,
					'F' => 0,
				];
				
				// distribute each grade according to the interval
				foreach ($marks as $mark) {
					// A: >=70
					if ($mark >= 70) {
						$gradeDistribution['A']++;

					// B: >=60 and <70
					} elseif ($mark >= 60 and $mark < 70) {
						$gradeDistribution['B']++;

					// C: >=50 and <60
					} elseif ($mark >= 50 and $mark < 60) {
						$gradeDistribution['C']++;

					// D: >=40 and <50
					} elseif ($mark >= 40 and $mark < 50) {
						$gradeDistribution['D']++;

					// F: <40
					} elseif ($mark < 40) {
						$gradeDistribution['F']++;
					} 
				}

				return array($gradeDistribution);
			}

			// Generate HTML table for grade distribution
			function generateGradeDistributionTable($gradeDistribution) {
			    $html = "<table>";
				$html .= "<tr>";

				foreach ($gradeDistribution as $grade => $count) {
					$html .= "<th>$grade</th>";
				}

				$html .= "<th>TOTAL</th></tr><tr>";

				$total = 0;

				foreach ($gradeDistribution as $grade => $count) {
					$html .= "<td>$count</td>";
					$total += $count;
				}

				$html .= "<td>$total</td></tr></table>";
				return $html;
			}

			function getFilenameFromDataFolder(){
				$folderPath = './data'; // Specify the folder path

				// Get the list of files in the folder
				$files = scandir($folderPath);

				// Iterate over the files
				foreach ($files as $file) {
					// Verify current directory (.)
					if ($file === '.') {
						continue;
					}

					// Check if the file has a .txt extension
					if (pathinfo($file, PATHINFO_EXTENSION) !== 'txt') {
						continue;
					}

					// Process the file
					$filePath = $folderPath . '/' . $file;
					return $filePath;
				}
			}

			// Get the input filename from data folder
			$filename = getFilenameFromDataFolder();

			// Read marks from the file
			$marks = readMarksFromFile($filename);

			// Present the data series in the form [56,67…15]
			$dataSeries = formatDataSeries($marks);

			// Calculate the statistical mean mark from the data series
			$meanMark = calculateStatisticalMeanMark($marks);

			// Calculate the statistical range from the data series
			$range = calculateStatisticalRange($marks);

			// Determine the grade distribution
			list($gradeDistribution) = calculateGradeDistribution($marks);

			// Generate table for grade distribution
			$gradeDistributionTable = generateGradeDistributionTable($gradeDistribution);

			// Output
			echo "<p>Data Series: $dataSeries</p>";
			echo "<p>Mean Mark: $meanMark</p>";
			echo "<p>Range (max-min mark): $range</p>";
			echo "<p>Grade Distribution:</p>";
			echo $gradeDistributionTable;

		?>
    </main> 
</body>
</html>